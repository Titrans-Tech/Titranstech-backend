<!DOCTYPE html>
<html>
<head>
    <title>Contact Form Submission</title>
</head>
<body>
    <h3>Contact Form Submission</h3>
    <p><strong>Name:</strong> <?php echo e($data['name']); ?></p>
    <p><strong>Subject:</strong> <?php echo e($data['subject']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Message:</strong> <?php echo e($data['body']); ?></p>
</body><?php /**PATH C:\xampp\htdocs\Titranstech-backend\resources\views/emails/contact.blade.php ENDPATH**/ ?>
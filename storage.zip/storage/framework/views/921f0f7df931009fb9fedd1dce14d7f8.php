<!DOCTYPE html>
<html>
<head>
    <title>Contact Form Submission</title>
</head>
<body>
    <h1>Contact Form Submission</h1>
    <p><strong>Name:</strong> <?php echo e($data['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Message:</strong> <?php echo e($data['message']); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Titranstech-backend\resources\views/emails/contact_form.blade.php ENDPATH**/ ?>